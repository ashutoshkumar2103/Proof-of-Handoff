package com.handoffly.handoff;

import com.handoffly.common.domain.BaseEntity;
import com.handoffly.user.User;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.Table;
import org.hibernate.annotations.SQLRestriction;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/**
 * A lifecycle record of responsibility moving from a sender to a recipient, kept open
 * until the items are returned. Outgoing items are immutable after submission; returns
 * are recorded as separate events against this same handoff.
 */
@Entity
@Table(name = "handoff")
// A deleted draft is never loaded again, by any query, so no list, count, report, lookup or job can see it (see deletedAt).
@SQLRestriction("deleted_at is null")
public class Handoff extends BaseEntity {

    /**
     * The customer-facing reference (e.g. AV-3), issued when the draft is first submitted: null until then. Unique per owning
     * account — not globally — and immutable once issued, so PDFs, emails and audit history that quote it stay valid even if the
     * account's prefix later changes. (A draft created before references moved to submission keeps the one it was given.)
     */
    @Column(name = "public_code", length = 20)
    private String publicCode;

    /**
     * The draft's own reference (e.g. AVD-3), issued when it was created and never changed, even if the account's prefix does. It is not the
     * official reference and never becomes it; it is only what tells one draft from another before the handoff is submitted. Null for a handoff
     * that was numbered when it was created (it has its official reference). Unique per owning account.
     */
    @Column(name = "draft_code", length = 20)
    private String draftCode;

    /** The number inside {@link #publicCode} (3 for AV-3), so references sort in their real order; null while there is no reference. */
    @Column(name = "reference_number")
    private Long referenceNumber;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "owner_user_id", nullable = false)
    private User owner;

    @Column(nullable = false, length = 200)
    private String title;

    @Column(length = 2000)
    private String purpose;

    /** Domain/template category, e.g. "EVENT", "IT_EQUIPMENT" — free text, no per-domain code. */
    @Column(length = 60)
    private String category;

    @Column(name = "sender_name", nullable = false, length = 200)
    private String senderName;

    @Column(name = "sender_organization", length = 200)
    private String senderOrganization;

    @Column(name = "recipient_name", nullable = false, length = 200)
    private String recipientName;

    @Column(name = "recipient_email", nullable = false, length = 255)
    private String recipientEmail;

    @Column(name = "recipient_phone", length = 40)
    private String recipientPhone;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private HandoffStatus status = HandoffStatus.DRAFT;

    @Column(name = "outgoing_at")
    private Instant outgoingAt;

    @Column(name = "acceptance_at")
    private Instant acceptanceAt;

    /** Optional expected-return deadline, used to flag OVERDUE. */
    @Column(name = "due_at")
    private Instant dueAt;

    /** Typed acknowledgement name (NOT a legally binding e-signature). */
    @Column(name = "acknowledgement_name", length = 200)
    private String acknowledgementName;

    @Column(name = "acknowledged_at")
    private Instant acknowledgedAt;

    @Column(name = "rejection_reason", length = 1000)
    private String rejectionReason;

    /** Set when the owner asks the recipient to confirm items reported missing. */
    @Column(name = "missing_confirmation_requested_at")
    private Instant missingConfirmationRequestedAt;

    /** Set when the recipient confirms the missing items — required before closing. */
    @Column(name = "missing_confirmed_at")
    private Instant missingConfirmedAt;

    /** Typed acknowledgement name captured when the recipient confirms the missing items. */
    @Column(name = "missing_confirmed_by_name", length = 200)
    private String missingConfirmedByName;

    /** Set when the recipient requests to wait for return instead of confirming missing. */
    @Column(name = "return_wait_requested_at")
    private Instant returnWaitRequestedAt;

    @Column(name = "return_wait_reason", length = 1000)
    private String returnWaitReason;

    @Column(name = "return_wait_requested_by_name", length = 200)
    private String returnWaitRequestedByName;

    /**
     * Set when the customer deletes a draft. The row is kept, not erased: its audit events (append-only) and attachments still
     * point at it. Nothing reads a handoff with this set; see {@link #markDeleted}.
     */
    @Column(name = "deleted_at")
    private Instant deletedAt;

    @OneToMany(mappedBy = "handoff", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("position ASC, id ASC")
    private List<HandoffItem> items = new ArrayList<>();

    protected Handoff() {
        // JPA
    }

    /** A new draft: it has no reference yet (see {@link #assignReference}). */
    public Handoff(User owner, String title) {
        this.owner = owner;
        this.title = title;
    }

    /** Gives a new draft its own reference, once, when it is created. */
    public void assignDraftCode(String draftCode) {
        if (this.draftCode != null) {
            throw new IllegalStateException("This handoff already has a draft reference.");
        }
        this.draftCode = draftCode;
    }

    /** Gives a draft its reference, once, at its first submission. A handoff that already has one never gets another. */
    public void assignReference(String reference, long number) {
        if (this.publicCode != null) {
            throw new IllegalStateException("This handoff already has a reference.");
        }
        this.publicCode = reference;
        this.referenceNumber = number;
    }

    public void addItem(HandoffItem item) {
        item.setHandoff(this);
        item.setPosition(items.size());
        items.add(item);
    }

    /** Takes this handoff out of the workspace for good; what was recorded about it stays. */
    public void markDeleted(Instant at) {
        this.deletedAt = at;
    }

    public void clearItems() {
        items.clear();
    }

    public boolean isOwnedBy(Long userId) {
        return owner != null && owner.getId().equals(userId);
    }

    public String getPublicCode() { return publicCode; }

    public String getDraftCode() { return draftCode; }

    public Long getReferenceNumber() { return referenceNumber; }

    public User getOwner() { return owner; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getPurpose() { return purpose; }
    public void setPurpose(String purpose) { this.purpose = purpose; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getSenderName() { return senderName; }
    public void setSenderName(String senderName) { this.senderName = senderName; }

    public String getSenderOrganization() { return senderOrganization; }
    public void setSenderOrganization(String senderOrganization) { this.senderOrganization = senderOrganization; }

    public String getRecipientName() { return recipientName; }
    public void setRecipientName(String recipientName) { this.recipientName = recipientName; }

    public String getRecipientEmail() { return recipientEmail; }
    public void setRecipientEmail(String recipientEmail) { this.recipientEmail = recipientEmail; }

    public String getRecipientPhone() { return recipientPhone; }
    public void setRecipientPhone(String recipientPhone) { this.recipientPhone = recipientPhone; }

    public HandoffStatus getStatus() { return status; }
    public void setStatus(HandoffStatus status) { this.status = status; }

    public Instant getOutgoingAt() { return outgoingAt; }
    public void setOutgoingAt(Instant outgoingAt) { this.outgoingAt = outgoingAt; }

    public Instant getAcceptanceAt() { return acceptanceAt; }
    public void setAcceptanceAt(Instant acceptanceAt) { this.acceptanceAt = acceptanceAt; }

    public Instant getDueAt() { return dueAt; }
    public void setDueAt(Instant dueAt) { this.dueAt = dueAt; }

    public String getAcknowledgementName() { return acknowledgementName; }
    public void setAcknowledgementName(String acknowledgementName) { this.acknowledgementName = acknowledgementName; }

    public Instant getAcknowledgedAt() { return acknowledgedAt; }
    public void setAcknowledgedAt(Instant acknowledgedAt) { this.acknowledgedAt = acknowledgedAt; }

    public String getRejectionReason() { return rejectionReason; }
    public void setRejectionReason(String rejectionReason) { this.rejectionReason = rejectionReason; }

    public Instant getMissingConfirmationRequestedAt() { return missingConfirmationRequestedAt; }
    public void setMissingConfirmationRequestedAt(Instant at) { this.missingConfirmationRequestedAt = at; }

    public Instant getMissingConfirmedAt() { return missingConfirmedAt; }
    public void setMissingConfirmedAt(Instant at) { this.missingConfirmedAt = at; }

    public String getMissingConfirmedByName() { return missingConfirmedByName; }
    public void setMissingConfirmedByName(String name) { this.missingConfirmedByName = name; }

    public Instant getReturnWaitRequestedAt() { return returnWaitRequestedAt; }
    public void setReturnWaitRequestedAt(Instant at) { this.returnWaitRequestedAt = at; }

    public String getReturnWaitReason() { return returnWaitReason; }
    public void setReturnWaitReason(String reason) { this.returnWaitReason = reason; }

    public String getReturnWaitRequestedByName() { return returnWaitRequestedByName; }
    public void setReturnWaitRequestedByName(String name) { this.returnWaitRequestedByName = name; }

    public List<HandoffItem> getItems() { return items; }
}

package com.handoffly.handoff;

import com.handoffly.audit.dto.AuditEventResponse;
import com.handoffly.auth.UserPrincipal;
import com.handoffly.common.web.PageResponse;
import com.handoffly.handoff.dto.CreateHandoffRequest;
import com.handoffly.handoff.dto.DashboardResponse;
import com.handoffly.handoff.dto.EmailPdfRequest;
import com.handoffly.handoff.dto.EmailPdfResponse;
import com.handoffly.handoff.dto.HandoffDetailResponse;
import com.handoffly.handoff.dto.HandoffSummaryResponse;
import com.handoffly.handoff.dto.HandoffTemplateResponse;
import com.handoffly.handoff.dto.ReasonRequest;
import com.handoffly.handoff.dto.ReplaceItemsRequest;
import com.handoffly.handoff.dto.UpdateHandoffRequest;
import jakarta.validation.Valid;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.CacheControl;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/handoffs")
public class HandoffController {

    private final HandoffService handoffService;
    private final HandoffPdfService pdfService;
    private final HandoffExcelService excelService;

    public HandoffController(HandoffService handoffService, HandoffPdfService pdfService, HandoffExcelService excelService) {
        this.handoffService = handoffService;
        this.pdfService = pdfService;
        this.excelService = excelService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public HandoffDetailResponse create(@AuthenticationPrincipal UserPrincipal principal,
                                        @Valid @RequestBody CreateHandoffRequest request) {
        return handoffService.create(principal.id(), request);
    }

    @GetMapping
    public PageResponse<HandoffSummaryResponse> list(
            @AuthenticationPrincipal UserPrincipal principal,
            @RequestParam(required = false) List<HandoffStatus> status,
            @RequestParam(required = false) String q,
            @PageableDefault(size = 20) Pageable pageable) {
        return handoffService.list(principal.id(), status, q, pageable);
    }

    @GetMapping("/dashboard")
    public DashboardResponse dashboard(@AuthenticationPrincipal UserPrincipal principal) {
        return handoffService.dashboard(principal.id());
    }

    @GetMapping("/{id}")
    public HandoffDetailResponse get(@AuthenticationPrincipal UserPrincipal principal,
                                     @PathVariable Long id) {
        return handoffService.getDetail(principal.id(), id);
    }

    /** The reusable part of this handoff, to prefill a NEW draft with (nothing is created by asking). */
    @GetMapping("/{id}/template")
    public HandoffTemplateResponse template(@AuthenticationPrincipal UserPrincipal principal,
                                            @PathVariable Long id) {
        return handoffService.templateOf(principal.id(), id);
    }

    @GetMapping("/{id}/events")
    public List<AuditEventResponse> events(@AuthenticationPrincipal UserPrincipal principal,
                                           @PathVariable Long id) {
        return handoffService.getEvents(principal.id(), id);
    }

    /** The Proof-of-Handoff record as a PDF, generated on demand (never stored). */
    @GetMapping("/{id}/pdf")
    public ResponseEntity<byte[]> pdf(@AuthenticationPrincipal UserPrincipal principal,
                                      @PathVariable Long id) {
        HandoffPdfService.PdfFile file = pdfService.generate(principal.id(), id);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        ContentDisposition.attachment().filename(file.filename()).build().toString())
                .cacheControl(CacheControl.noStore())
                .contentType(MediaType.APPLICATION_PDF)
                .contentLength(file.content().length)
                .body(file.content());
    }

    /** The same record as an Excel workbook, generated on demand in any status (never stored). */
    @GetMapping("/{id}/excel")
    public ResponseEntity<byte[]> excel(@AuthenticationPrincipal UserPrincipal principal,
                                        @PathVariable Long id) {
        HandoffExcelService.ExcelFile file = excelService.generate(principal.id(), id);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        ContentDisposition.attachment().filename(file.filename()).build().toString())
                .cacheControl(CacheControl.noStore())
                .contentType(MediaType.parseMediaType(HandoffExcelService.CONTENT_TYPE))
                .contentLength(file.content().length)
                .body(file.content());
    }

    /** Emails the PDF as an attachment. Explicit action only; defaults to the handoff's recipient. */
    @PostMapping("/{id}/email-pdf")
    public EmailPdfResponse emailPdf(@AuthenticationPrincipal UserPrincipal principal,
                                     @PathVariable Long id,
                                     @Valid @RequestBody(required = false) EmailPdfRequest request) {
        return pdfService.emailPdf(principal.id(), id, request == null ? null : request.to());
    }

    @PatchMapping("/{id}")
    public HandoffDetailResponse update(@AuthenticationPrincipal UserPrincipal principal,
                                        @PathVariable Long id,
                                        @Valid @RequestBody UpdateHandoffRequest request) {
        return handoffService.update(principal.id(), id, request);
    }

    @PutMapping("/{id}/items")
    public HandoffDetailResponse replaceItems(@AuthenticationPrincipal UserPrincipal principal,
                                              @PathVariable Long id,
                                              @Valid @RequestBody ReplaceItemsRequest request) {
        return handoffService.replaceItems(principal.id(), id, request);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@AuthenticationPrincipal UserPrincipal principal, @PathVariable Long id) {
        handoffService.deleteDraft(principal.id(), id);
    }

    @PostMapping("/{id}/submit")
    public HandoffDetailResponse submit(@AuthenticationPrincipal UserPrincipal principal,
                                        @PathVariable Long id) {
        return handoffService.submit(principal.id(), id);
    }

    @PostMapping("/{id}/resend-link")
    public HandoffDetailResponse resendLink(@AuthenticationPrincipal UserPrincipal principal,
                                            @PathVariable Long id) {
        return handoffService.resendLink(principal.id(), id);
    }

    @PostMapping("/{id}/cancel")
    public HandoffDetailResponse cancel(@AuthenticationPrincipal UserPrincipal principal,
                                        @PathVariable Long id,
                                        @Valid @RequestBody(required = false) ReasonRequest request) {
        return handoffService.cancel(principal.id(), id, request == null ? null : request.reason());
    }

    @PostMapping("/{id}/dispute")
    public HandoffDetailResponse dispute(@AuthenticationPrincipal UserPrincipal principal,
                                         @PathVariable Long id,
                                         @Valid @RequestBody(required = false) ReasonRequest request) {
        return handoffService.dispute(principal.id(), id, request == null ? null : request.reason());
    }

    @PostMapping("/{id}/close")
    public HandoffDetailResponse close(@AuthenticationPrincipal UserPrincipal principal,
                                       @PathVariable Long id,
                                       @Valid @RequestBody(required = false) ReasonRequest request) {
        return handoffService.close(principal.id(), id, request == null ? null : request.reason());
    }

    @PostMapping("/{id}/request-missing-confirmation")
    public HandoffDetailResponse requestMissingConfirmation(@AuthenticationPrincipal UserPrincipal principal,
                                                            @PathVariable Long id) {
        return handoffService.requestMissingConfirmation(principal.id(), id);
    }
}

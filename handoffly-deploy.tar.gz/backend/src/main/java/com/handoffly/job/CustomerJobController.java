package com.handoffly.job;

import com.handoffly.auth.UserPrincipal;
import com.handoffly.common.web.PageResponse;
import com.handoffly.job.dto.JobChangeResponse;
import com.handoffly.job.dto.JobHistoryResponse;
import com.handoffly.job.dto.JobResponse;
import com.handoffly.job.dto.JobRunResponse;
import com.handoffly.job.dto.SetEnabledRequest;
import com.handoffly.job.dto.UpdateScheduleRequest;
import jakarta.validation.Valid;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * The signed-in customer's own jobs. Every call acts on the caller's jobs only: a job is addressed by its kind, and
 * the owner is always the authenticated customer — there is no id in a URL that could name someone else's.
 */
@RestController
@RequestMapping("/api/v1/account/jobs")
public class CustomerJobController {

    private final CustomerJobService service;

    public CustomerJobController(CustomerJobService service) {
        this.service = service;
    }

    @GetMapping
    public List<JobResponse> list(@AuthenticationPrincipal UserPrincipal principal) {
        return service.list(principal.id());
    }

    /** The caller's Job History: every run of every job, newest first. Only the caller's own runs, whatever the parameters. */
    @GetMapping("/history")
    public PageResponse<JobHistoryResponse> history(@AuthenticationPrincipal UserPrincipal principal,
                                                    @PageableDefault(size = 20) Pageable pageable) {
        return service.history(principal.id(), pageable);
    }

    /** The caller's Configuration Changes: who changed the schedule of a job, or paused or resumed it, newest first. Only the caller's own. */
    @GetMapping("/changes")
    public PageResponse<JobChangeResponse> changes(@AuthenticationPrincipal UserPrincipal principal,
                                                   @PageableDefault(size = 20) Pageable pageable) {
        return service.changes(principal.id(), pageable);
    }

    /** Runs all five jobs once, now (each is its own run). No schedule changes. */
    @PostMapping("/run-all")
    public List<JobRunResponse> runAll(@AuthenticationPrincipal UserPrincipal principal) {
        return service.runAllNow(principal.id());
    }

    @PutMapping("/{type}/schedule")
    public JobResponse updateSchedule(@AuthenticationPrincipal UserPrincipal principal, @PathVariable JobType type,
                                      @Valid @RequestBody UpdateScheduleRequest request) {
        return service.updateSchedule(principal.id(), type, request.cronExpression(), request.timezone());
    }

    @PutMapping("/{type}/enabled")
    public JobResponse setEnabled(@AuthenticationPrincipal UserPrincipal principal, @PathVariable JobType type,
                                  @Valid @RequestBody SetEnabledRequest request) {
        return service.setEnabled(principal.id(), type, request.enabled());
    }

    /** Runs this job once, now. The schedule and whether it is on are not touched. */
    @PostMapping("/{type}/run")
    public JobRunResponse run(@AuthenticationPrincipal UserPrincipal principal, @PathVariable JobType type) {
        return service.runNow(principal.id(), type);
    }
}

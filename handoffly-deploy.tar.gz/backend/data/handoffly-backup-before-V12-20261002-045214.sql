-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: handoffly
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `app_user`
--

DROP TABLE IF EXISTS `app_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `version` bigint NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(100) NOT NULL,
  `display_name` varchar(150) NOT NULL,
  `organization` varchar(200) DEFAULT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'USER',
  `enabled` tinyint(1) NOT NULL,
  `account_code` varchar(20) NOT NULL DEFAULT '',
  `phone` varchar(40) DEFAULT NULL,
  `subscription_plan` varchar(20) NOT NULL DEFAULT 'MONTHLY',
  `handoff_prefix` varchar(5) NOT NULL DEFAULT 'HO',
  `handoff_sequence` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_app_user_email` (`email`),
  UNIQUE KEY `uq_app_user_account_code` (`account_code`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_user`
--

LOCK TABLES `app_user` WRITE;
/*!40000 ALTER TABLE `app_user` DISABLE KEYS */;
INSERT INTO `app_user` VALUES (1,0,'2026-09-28 18:19:40.292151','2026-09-28 18:19:40.292151','handoffly@gmail.com','$2a$10$pxC8Iq7SHqB9xv2W6eR5wedVllaUrdIVUx9PxVY7Z.QN.Bwk6K.12','Ashutosh','testowner','USER',1,'CUS-000001',NULL,'MONTHLY','HO',6),(9,0,'2026-10-01 20:57:13.822028','2026-10-01 20:57:13.822028','kumarpari9122@gmail.com','$2a$10$FMQfaugr5ZwJbynODIiBRelMi0NVqSIL/NhtcDM4Y5.DGV8Qk5oWS','Abhinay Kumar','Educational','USER',1,'CUS-000009',NULL,'YEARLY','HO',14);
/*!40000 ALTER TABLE `app_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attachment`
--

DROP TABLE IF EXISTS `attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attachment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `version` bigint NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `handoff_id` bigint NOT NULL,
  `kind` varchar(30) NOT NULL,
  `storage_key` varchar(100) NOT NULL,
  `original_filename` varchar(255) NOT NULL,
  `content_type` varchar(100) NOT NULL,
  `size_bytes` bigint NOT NULL,
  `uploaded_by_type` varchar(20) NOT NULL,
  `uploaded_by_ref` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_attachment_handoff` (`handoff_id`),
  CONSTRAINT `fk_attachment_handoff` FOREIGN KEY (`handoff_id`) REFERENCES `handoff` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachment`
--

LOCK TABLES `attachment` WRITE;
/*!40000 ALTER TABLE `attachment` DISABLE KEYS */;
INSERT INTO `attachment` VALUES (1,0,'2026-09-28 18:23:44.399521','2026-09-28 18:23:44.399521',1,'EVIDENCE','e96469d826554f3e845593773f0302cd','train.png','image/png',465458,'USER','handoffly@gmail.com'),(2,0,'2026-09-28 19:43:37.793654','2026-09-28 19:43:37.793654',3,'EVIDENCE','04055131eac34cc58948a3f31f2b5797','train.png','image/png',465458,'USER','handoffly@gmail.com');
/*!40000 ALTER TABLE `attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_event`
--

DROP TABLE IF EXISTS `audit_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_event` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `version` bigint NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `handoff_id` bigint NOT NULL,
  `event_type` varchar(40) NOT NULL,
  `actor_type` varchar(20) NOT NULL,
  `actor_ref` varchar(200) DEFAULT NULL,
  `message` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_audit_handoff` (`handoff_id`),
  CONSTRAINT `fk_audit_handoff` FOREIGN KEY (`handoff_id`) REFERENCES `handoff` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=125 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_event`
--

LOCK TABLES `audit_event` WRITE;
/*!40000 ALTER TABLE `audit_event` DISABLE KEYS */;
INSERT INTO `audit_event` VALUES (1,0,'2026-09-28 18:23:17.967472','2026-09-28 18:23:17.967472',1,'HANDOFF_CREATED','USER','handoffly@gmail.com','Handoff created as draft.'),(2,0,'2026-09-28 18:23:23.950810','2026-09-28 18:23:23.950810',1,'HANDOFF_UPDATED','USER','handoffly@gmail.com','Handoff details updated.'),(3,0,'2026-09-28 18:23:24.164237','2026-09-28 18:23:24.164237',1,'HANDOFF_UPDATED','USER','handoffly@gmail.com','Handoff items updated.'),(4,0,'2026-09-28 18:23:44.412605','2026-09-28 18:23:44.412605',1,'ATTACHMENT_ADDED','USER','handoffly@gmail.com','Attachment added: train.png.'),(5,0,'2026-09-28 18:23:55.383307','2026-09-28 18:23:55.383307',1,'HANDOFF_UPDATED','USER','handoffly@gmail.com','Handoff details updated.'),(6,0,'2026-09-28 18:23:55.422198','2026-09-28 18:23:55.422198',1,'HANDOFF_UPDATED','USER','handoffly@gmail.com','Handoff items updated.'),(7,0,'2026-09-28 18:24:11.065984','2026-09-28 18:24:11.065984',1,'OUTGOING_SUBMITTED','USER','handoffly@gmail.com','Outgoing handoff submitted.'),(8,0,'2026-09-28 18:24:11.099788','2026-09-28 18:24:11.099788',1,'RECIPIENT_LINK_SENT','SYSTEM',NULL,'Secure review link emailed to ashuatif14347@gmail.com.'),(9,0,'2026-09-28 18:25:21.544614','2026-09-28 18:25:21.544614',1,'RECIPIENT_OPENED','RECIPIENT','Ashutosh','Recipient opened the review link.'),(10,0,'2026-09-28 18:26:09.718947','2026-09-28 18:26:09.718947',1,'RECIPIENT_REJECTED','RECIPIENT','Ashutosh','Recipient rejected the handoff.'),(11,0,'2026-09-28 19:14:40.427905','2026-09-28 19:14:40.427905',2,'HANDOFF_CREATED','USER','handoffly@gmail.com','Handoff created as draft.'),(12,0,'2026-09-28 19:14:42.080288','2026-09-28 19:14:42.080288',2,'OUTGOING_SUBMITTED','USER','handoffly@gmail.com','Outgoing handoff submitted.'),(13,0,'2026-09-28 19:14:42.101739','2026-09-28 19:14:42.101739',2,'RECIPIENT_LINK_SENT','SYSTEM',NULL,'Secure review link emailed to ashuatif14347@gmail.com.'),(14,0,'2026-09-28 19:14:54.147817','2026-09-28 19:14:54.147817',2,'RECIPIENT_OPENED','RECIPIENT','Ashutosh','Recipient opened the review link.'),(15,0,'2026-09-28 19:16:08.440943','2026-09-28 19:16:08.440943',2,'RECIPIENT_ACCEPTED','RECIPIENT','Ashutosh','Recipient accepted and acknowledged the handoff.'),(16,0,'2026-09-28 19:19:49.737150','2026-09-28 19:19:49.737150',2,'RETURN_CREATED','USER','handoffly@gmail.com','Return recorded and confirmed.'),(17,0,'2026-09-28 19:19:49.739260','2026-09-28 19:19:49.739260',2,'RETURN_CONFIRMED','USER','handoffly@gmail.com','Return confirmed.'),(18,0,'2026-09-28 19:20:28.220764','2026-09-28 19:20:28.220764',2,'RETURN_CREATED','USER','handoffly@gmail.com','Return recorded and confirmed.'),(19,0,'2026-09-28 19:20:28.220764','2026-09-28 19:20:28.220764',2,'RETURN_CONFIRMED','USER','handoffly@gmail.com','Return confirmed.'),(20,0,'2026-09-28 19:20:59.862324','2026-09-28 19:20:59.862324',2,'HANDOFF_CLOSED','USER','handoffly@gmail.com','Handoff closed.'),(21,0,'2026-09-28 19:42:58.364157','2026-09-28 19:42:58.364157',3,'HANDOFF_CREATED','USER','handoffly@gmail.com','Handoff created as draft.'),(22,0,'2026-09-28 19:43:05.473802','2026-09-28 19:43:05.473802',3,'OUTGOING_SUBMITTED','USER','handoffly@gmail.com','Outgoing handoff submitted.'),(23,0,'2026-09-28 19:43:05.510736','2026-09-28 19:43:05.510736',3,'RECIPIENT_LINK_SENT','SYSTEM',NULL,'Secure review link emailed to ashuatif14347@gmail.com.'),(24,0,'2026-09-28 19:43:19.275986','2026-09-28 19:43:19.275986',3,'RECIPIENT_OPENED','RECIPIENT','Rahul','Recipient opened the review link.'),(25,0,'2026-09-28 19:43:37.797675','2026-09-28 19:43:37.797675',3,'ATTACHMENT_ADDED','USER','handoffly@gmail.com','Attachment added: train.png.'),(26,0,'2026-09-28 19:44:08.332834','2026-09-28 19:44:08.332834',3,'RECIPIENT_ACCEPTED','RECIPIENT','Rahul','Recipient accepted and acknowledged the handoff.'),(27,0,'2026-09-28 19:49:45.286373','2026-09-28 19:49:45.286373',3,'RETURN_CREATED','USER','handoffly@gmail.com','Return recorded and confirmed.'),(28,0,'2026-09-28 19:49:45.287378','2026-09-28 19:49:45.287378',3,'RETURN_CONFIRMED','USER','handoffly@gmail.com','Return confirmed.'),(29,0,'2026-09-28 19:57:03.376590','2026-09-28 19:57:03.376590',3,'HANDOFF_DISPUTED','USER','handoffly@gmail.com','Handoff marked as disputed.'),(30,0,'2026-09-28 19:57:10.040477','2026-09-28 19:57:10.040477',3,'HANDOFF_CLOSED','USER','handoffly@gmail.com','Handoff closed.'),(31,0,'2026-09-30 14:57:03.210597','2026-09-30 14:57:03.210597',4,'HANDOFF_CREATED','USER','handoffly@gmail.com','Handoff created as draft.'),(32,0,'2026-09-30 14:57:17.361464','2026-09-30 14:57:17.361464',4,'OUTGOING_SUBMITTED','USER','handoffly@gmail.com','Outgoing handoff submitted.'),(33,0,'2026-09-30 14:57:17.499821','2026-09-30 14:57:17.499821',4,'RECIPIENT_LINK_SENT','SYSTEM',NULL,'Secure review link emailed to ashuatif14347@gmail.com.'),(34,0,'2026-09-30 14:57:42.600891','2026-09-30 14:57:42.600891',4,'RECIPIENT_OPENED','RECIPIENT','Priya','Recipient opened the review link.'),(35,0,'2026-09-30 14:58:05.122697','2026-09-30 14:58:05.122697',4,'RECIPIENT_ACCEPTED','RECIPIENT','Priya','Recipient accepted and acknowledged the handoff.'),(36,0,'2026-09-30 14:58:51.479135','2026-09-30 14:58:51.479135',4,'RETURN_CREATED','USER','handoffly@gmail.com','Return recorded and confirmed.'),(37,0,'2026-09-30 14:58:51.482619','2026-09-30 14:58:51.482619',4,'RETURN_CONFIRMED','USER','handoffly@gmail.com','Return confirmed.'),(38,0,'2026-09-30 14:59:13.155414','2026-09-30 14:59:13.155414',4,'HANDOFF_CLOSED','USER','handoffly@gmail.com','Handoff closed.'),(39,0,'2026-09-30 15:27:56.153320','2026-09-30 15:27:56.153320',5,'HANDOFF_CREATED','USER','handoffly@gmail.com','Handoff created as draft.'),(40,0,'2026-09-30 15:27:59.308391','2026-09-30 15:27:59.308391',5,'OUTGOING_SUBMITTED','USER','handoffly@gmail.com','Outgoing handoff submitted.'),(41,0,'2026-09-30 15:27:59.385906','2026-09-30 15:27:59.385906',5,'RECIPIENT_LINK_SENT','SYSTEM',NULL,'Secure review link emailed to ashuatif14347@gmail.com.'),(42,0,'2026-09-30 15:28:11.202733','2026-09-30 15:28:11.202733',5,'RECIPIENT_OPENED','RECIPIENT','Parthiv','Recipient opened the review link.'),(43,0,'2026-09-30 15:29:01.706768','2026-09-30 15:29:01.706768',5,'RECIPIENT_ACCEPTED','RECIPIENT','Parthiv','Recipient accepted and acknowledged the handoff.'),(44,0,'2026-09-30 15:30:44.043178','2026-09-30 15:30:44.043178',5,'RETURN_CREATED','USER','handoffly@gmail.com','Return recorded and confirmed.'),(45,0,'2026-09-30 15:30:44.045726','2026-09-30 15:30:44.045726',5,'RETURN_CONFIRMED','USER','handoffly@gmail.com','Return confirmed.'),(46,0,'2026-09-30 15:41:58.643766','2026-09-30 15:41:58.643766',5,'RETURN_CREATED','USER','handoffly@gmail.com','Return recorded and confirmed.'),(47,0,'2026-09-30 15:41:58.653559','2026-09-30 15:41:58.653559',5,'RETURN_CONFIRMED','USER','handoffly@gmail.com','Return confirmed.'),(48,0,'2026-10-01 14:16:23.522832','2026-10-01 14:16:23.522832',5,'MISSING_CONFIRMATION_REQUESTED','USER','handoffly@gmail.com','Requested recipient to confirm missing items.'),(49,0,'2026-10-01 14:16:32.487335','2026-10-01 14:16:32.487335',5,'RECIPIENT_OPENED','RECIPIENT','Parthiv','Recipient opened the review link.'),(50,0,'2026-10-01 14:29:29.186097','2026-10-01 14:29:29.186097',6,'HANDOFF_CREATED','USER','handoffly@gmail.com','Handoff created as draft.'),(51,0,'2026-10-01 14:29:30.897634','2026-10-01 14:29:30.897634',6,'OUTGOING_SUBMITTED','USER','handoffly@gmail.com','Outgoing handoff submitted.'),(52,0,'2026-10-01 14:29:30.909966','2026-10-01 14:29:30.909966',6,'RECIPIENT_LINK_SENT','SYSTEM',NULL,'Secure review link emailed to ashuatif14347@gmail.com.'),(53,0,'2026-10-01 14:29:40.092164','2026-10-01 14:29:40.092164',6,'RECIPIENT_OPENED','RECIPIENT','Rishab','Recipient opened the review link.'),(54,0,'2026-10-01 14:29:58.928899','2026-10-01 14:29:58.928899',6,'RECIPIENT_ACCEPTED','RECIPIENT','Rishab','Recipient accepted and acknowledged the handoff.'),(85,0,'2026-10-01 15:29:48.212927','2026-10-01 15:29:48.212927',5,'RETURN_CREATED','USER','handoffly@gmail.com','Return recorded and confirmed.'),(86,0,'2026-10-01 15:29:48.212927','2026-10-01 15:29:48.212927',5,'RETURN_CONFIRMED','USER','handoffly@gmail.com','Return confirmed.'),(87,0,'2026-10-01 15:33:55.679783','2026-10-01 15:33:55.679783',5,'RETURN_CREATED','USER','handoffly@gmail.com','Return recorded and confirmed.'),(88,0,'2026-10-01 15:33:55.681219','2026-10-01 15:33:55.681219',5,'RETURN_CONFIRMED','USER','handoffly@gmail.com','Return confirmed.'),(89,0,'2026-10-01 15:34:08.541302','2026-10-01 15:34:08.541302',5,'HANDOFF_CLOSED','USER','handoffly@gmail.com','Handoff closed.'),(90,0,'2026-10-01 15:47:01.547735','2026-10-01 15:47:01.547735',3,'RETURN_CREATED','USER','handoffly@gmail.com','Return recorded and confirmed.'),(91,0,'2026-10-01 15:47:01.555408','2026-10-01 15:47:01.555408',3,'RETURN_CONFIRMED','USER','handoffly@gmail.com','Return confirmed.'),(104,0,'2026-10-01 15:57:48.517615','2026-10-01 15:57:48.517615',3,'MISSING_CONFIRMATION_REQUESTED','USER','handoffly@gmail.com','Requested recipient to confirm missing items.'),(105,0,'2026-10-01 15:57:58.673964','2026-10-01 15:57:58.673964',3,'RECIPIENT_OPENED','RECIPIENT','Rahul','Recipient opened the review link.'),(106,0,'2026-10-01 15:58:14.262976','2026-10-01 15:58:14.262976',3,'MISSING_CONFIRMED','RECIPIENT','Rahul','Recipient confirmed the missing items.'),(107,0,'2026-10-01 15:59:28.027263','2026-10-01 15:59:28.027263',6,'RETURN_CREATED','USER','handoffly@gmail.com','Return recorded and confirmed.'),(108,0,'2026-10-01 15:59:28.029281','2026-10-01 15:59:28.029281',6,'RETURN_CONFIRMED','USER','handoffly@gmail.com','Return confirmed.'),(109,0,'2026-10-01 15:59:37.337737','2026-10-01 15:59:37.337737',6,'MISSING_CONFIRMATION_REQUESTED','USER','handoffly@gmail.com','Requested recipient to confirm missing items.'),(110,0,'2026-10-01 15:59:45.382105','2026-10-01 15:59:45.382105',6,'RECIPIENT_OPENED','RECIPIENT','Rishab','Recipient opened the review link.'),(119,0,'2026-10-01 16:09:21.514179','2026-10-01 16:09:21.514179',3,'HANDOFF_CLOSED','USER','handoffly@gmail.com','Handoff closed with missing items. Reason: missing and confirmed by customer'),(120,0,'2026-10-01 16:58:21.105651','2026-10-01 16:58:21.105651',6,'RETURN_WAIT_REQUESTED','RECIPIENT','Rishab','Recipient requested to wait for return: Will send tomorrow'),(121,0,'2026-10-01 18:13:43.504950','2026-10-01 18:13:43.504950',6,'RETURN_CREATED','USER','handoffly@gmail.com','Return recorded and confirmed.'),(122,0,'2026-10-01 18:13:43.510981','2026-10-01 18:13:43.510981',6,'RETURN_CONFIRMED','USER','handoffly@gmail.com','Return confirmed.'),(123,0,'2026-10-01 18:13:48.203926','2026-10-01 18:13:48.203926',6,'HANDOFF_CLOSED','USER','handoffly@gmail.com','Handoff closed.'),(124,0,'2026-10-01 20:59:16.427771','2026-10-01 20:59:16.427771',14,'HANDOFF_CREATED','USER','kumarpari9122@gmail.com','Handoff created as draft.');
/*!40000 ALTER TABLE `audit_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyway_schema_history`
--

DROP TABLE IF EXISTS `flyway_schema_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flyway_schema_history` (
  `installed_rank` int NOT NULL,
  `version` varchar(50) DEFAULT NULL,
  `description` varchar(200) NOT NULL,
  `type` varchar(20) NOT NULL,
  `script` varchar(1000) NOT NULL,
  `checksum` int DEFAULT NULL,
  `installed_by` varchar(100) NOT NULL,
  `installed_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `execution_time` int NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`installed_rank`),
  KEY `flyway_schema_history_s_idx` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyway_schema_history`
--

LOCK TABLES `flyway_schema_history` WRITE;
/*!40000 ALTER TABLE `flyway_schema_history` DISABLE KEYS */;
INSERT INTO `flyway_schema_history` VALUES (1,'1','init','SQL','V1__init.sql',197950569,'handoffly','2026-09-28 18:10:26',409,1),(2,'2','handoff item condition','SQL','V2__handoff_item_condition.sql',-1799525286,'handoffly','2026-09-28 19:09:27',198,1),(3,'3','handoff missing confirmation','SQL','V3__handoff_missing_confirmation.sql',-469405322,'handoffly','2026-09-30 15:22:52',313,1),(4,'4','reclassify legacy missing returns','SQL','V4__reclassify_legacy_missing_returns.sql',398411637,'handoffly','2026-09-30 15:40:47',21,1),(5,'5','fix fully returned with missing','SQL','V5__fix_fully_returned_with_missing.sql',776968770,'handoffly','2026-09-30 16:38:57',25,1),(6,'6','sequential public codes','SQL','V6__sequential_public_codes.sql',-1330020501,'handoffly','2026-09-30 16:56:04',25,1),(7,'7','reopen closed with outstanding','SQL','V7__reopen_closed_with_outstanding.sql',1647374376,'handoffly','2026-10-01 15:42:05',80,1),(8,'8','missing confirmed by name','SQL','V8__missing_confirmed_by_name.sql',1658380991,'handoffly','2026-10-01 16:07:22',502,1),(9,'9','return wait requested','SQL','V9__return_wait_requested.sql',564563423,'handoffly','2026-10-01 16:52:45',231,1),(10,'10','account identity and handoff numbering','SQL','V10__account_identity_and_handoff_numbering.sql',-2021943281,'handoffly','2026-10-01 22:30:48',632,1),(11,'11','support tickets','SQL','V11__support_tickets.sql',1560316841,'handoffly','2026-10-01 22:30:48',196,1),(12,'12','support staff identity','SQL','V12__support_staff_identity.sql',-745005304,'handoffly','2026-10-01 23:19:16',334,1);
/*!40000 ALTER TABLE `flyway_schema_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `handoff`
--

DROP TABLE IF EXISTS `handoff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `handoff` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `version` bigint NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `public_code` varchar(20) NOT NULL,
  `owner_user_id` bigint NOT NULL,
  `title` varchar(200) NOT NULL,
  `purpose` varchar(2000) DEFAULT NULL,
  `category` varchar(60) DEFAULT NULL,
  `sender_name` varchar(200) NOT NULL,
  `sender_organization` varchar(200) DEFAULT NULL,
  `recipient_name` varchar(200) NOT NULL,
  `recipient_email` varchar(255) NOT NULL,
  `recipient_phone` varchar(40) DEFAULT NULL,
  `status` varchar(30) NOT NULL,
  `outgoing_at` datetime(6) DEFAULT NULL,
  `acceptance_at` datetime(6) DEFAULT NULL,
  `due_at` datetime(6) DEFAULT NULL,
  `acknowledgement_name` varchar(200) DEFAULT NULL,
  `acknowledged_at` datetime(6) DEFAULT NULL,
  `rejection_reason` varchar(1000) DEFAULT NULL,
  `missing_confirmation_requested_at` datetime(6) DEFAULT NULL,
  `missing_confirmed_at` datetime(6) DEFAULT NULL,
  `missing_confirmed_by_name` varchar(200) DEFAULT NULL,
  `return_wait_requested_at` timestamp NULL DEFAULT NULL,
  `return_wait_reason` varchar(1000) DEFAULT NULL,
  `return_wait_requested_by_name` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_handoff_owner_code` (`owner_user_id`,`public_code`),
  KEY `ix_handoff_owner_status` (`owner_user_id`,`status`),
  KEY `ix_handoff_due_at` (`due_at`),
  CONSTRAINT `fk_handoff_owner` FOREIGN KEY (`owner_user_id`) REFERENCES `app_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `handoff`
--

LOCK TABLES `handoff` WRITE;
/*!40000 ALTER TABLE `handoff` DISABLE KEYS */;
INSERT INTO `handoff` VALUES (1,2,'2026-09-28 18:23:17.934799','2026-09-28 18:26:09.731547','HO-1',1,'Wedding Rental',NULL,'Wedding','Ashutosh','testowner','Ashutosh','ashuatif14347@gmail.com','7461842411','REJECTED','2026-09-28 18:24:11.065984',NULL,'2026-09-30 12:00:00.000000','Ashutosh','2026-09-28 18:26:09.718947',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,5,'2026-09-28 19:14:40.372616','2026-09-28 19:20:59.880206','HO-2',1,'Equipment issues',NULL,'IT_EQUIPMENT','Ashutosh','testowner','Ashutosh','ashuatif14347@gmail.com',NULL,'CLOSED','2026-09-28 19:14:42.074497','2026-09-28 19:16:08.440943',NULL,'Ashutosh','2026-09-28 19:16:08.440943',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,8,'2026-09-28 19:42:58.302357','2026-10-01 16:09:21.549229','HO-3',1,'Kitchen Utensils',NULL,'OTHER','Ashutosh','testowner','Rahul','ashuatif14347@gmail.com',NULL,'CLOSED','2026-09-28 19:43:05.473802','2026-09-28 19:44:08.332834','2026-10-01 10:00:00.000000','Rahul','2026-09-28 19:44:08.332834',NULL,'2026-10-01 15:57:48.517615','2026-10-01 15:58:14.261436',NULL,NULL,NULL,NULL),(4,4,'2026-09-30 14:57:02.943453','2026-09-30 14:59:13.176563','HO-4',1,'Bridal Costume',NULL,'Marriage','Ashutosh','testowner','Priya','ashuatif14347@gmail.com',NULL,'CLOSED','2026-09-30 14:57:17.330312','2026-09-30 14:58:05.122069','2026-10-01 18:30:00.000000','Priya','2026-09-30 14:58:05.122069',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(5,7,'2026-09-30 15:27:56.032111','2026-10-01 15:34:08.570248','HO-5',1,'Wedding Rental',NULL,'EVENT','Ashutosh','testowner','Parthiv','ashuatif14347@gmail.com',NULL,'CLOSED','2026-09-30 15:27:59.302089','2026-09-30 15:29:01.705030','2026-10-03 08:00:00.000000','Parthiv','2026-09-30 15:29:01.705030',NULL,'2026-10-01 14:16:23.507071',NULL,NULL,NULL,NULL,NULL),(6,8,'2026-10-01 14:29:29.158394','2026-10-01 18:13:48.219283','HO-6',1,'Birthday Celebration',NULL,'EVENT','Ashutosh','testowner','Rishab','ashuatif14347@gmail.com',NULL,'CLOSED','2026-10-01 14:29:30.897318','2026-10-01 14:29:58.928899','2026-10-03 07:30:00.000000','Rishab','2026-10-01 14:29:58.928899',NULL,'2026-10-01 15:59:37.337737',NULL,NULL,'2026-10-01 11:28:21','Will send tomorrow','Rishab'),(14,1,'2026-10-01 20:59:16.399459','2026-10-01 20:59:16.434826','HO-14',9,'Education',NULL,'OTHER','Abhinay Kumar','Educational','Kumar','kumarpari9122@gmail.com',NULL,'DRAFT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `handoff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `handoff_item`
--

DROP TABLE IF EXISTS `handoff_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `handoff_item` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `version` bigint NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `handoff_id` bigint NOT NULL,
  `name` varchar(300) NOT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `sku` varchar(80) DEFAULT NULL,
  `serial_number` varchar(120) DEFAULT NULL,
  `asset_number` varchar(120) DEFAULT NULL,
  `quantity` decimal(19,3) NOT NULL,
  `unit` varchar(30) DEFAULT NULL,
  `notes` varchar(1000) DEFAULT NULL,
  `sort_order` int NOT NULL,
  `item_condition` varchar(20) NOT NULL DEFAULT 'GOOD',
  PRIMARY KEY (`id`),
  KEY `ix_item_handoff` (`handoff_id`),
  CONSTRAINT `fk_item_handoff` FOREIGN KEY (`handoff_id`) REFERENCES `handoff` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `handoff_item`
--

LOCK TABLES `handoff_item` WRITE;
/*!40000 ALTER TABLE `handoff_item` DISABLE KEYS */;
INSERT INTO `handoff_item` VALUES (7,0,'2026-09-28 18:23:55.425048','2026-09-28 18:23:55.425048',1,'Chair',NULL,NULL,NULL,NULL,100.000,'piece',NULL,0,'GOOD'),(8,0,'2026-09-28 18:23:55.425048','2026-09-28 18:23:55.425048',1,'Table',NULL,NULL,NULL,NULL,25.000,'piece',NULL,1,'GOOD'),(9,0,'2026-09-28 18:23:55.425048','2026-09-28 18:23:55.425048',1,'Mattress',NULL,NULL,NULL,NULL,15.000,'piece',NULL,2,'GOOD'),(10,0,'2026-09-28 19:14:40.410449','2026-09-28 19:14:40.410449',2,'Laptop (HP)',NULL,NULL,NULL,NULL,1.000,'pcs',NULL,0,'GOOD'),(11,0,'2026-09-28 19:14:40.411129','2026-09-28 19:14:40.411129',2,'Charger',NULL,NULL,NULL,NULL,1.000,'pcs',NULL,1,'GOOD'),(12,0,'2026-09-28 19:14:40.417808','2026-09-28 19:14:40.417808',2,'Earphone',NULL,NULL,NULL,NULL,1.000,'pcs',NULL,2,'GOOD'),(13,0,'2026-09-28 19:14:40.417808','2026-09-28 19:14:40.417808',2,'Headphone',NULL,NULL,NULL,NULL,1.000,'pcs',NULL,3,'GOOD'),(14,0,'2026-09-28 19:42:58.345313','2026-09-28 19:42:58.345313',3,'Steel Plate',NULL,NULL,NULL,NULL,7.000,'pcs',NULL,0,'GOOD'),(15,0,'2026-09-28 19:42:58.350734','2026-09-28 19:42:58.350734',3,'Steel Glass',NULL,NULL,NULL,NULL,7.000,'pcs',NULL,1,'GOOD'),(16,0,'2026-09-28 19:42:58.352735','2026-09-28 19:42:58.352735',3,'Table Spoon',NULL,NULL,NULL,NULL,7.000,'pcs',NULL,2,'GOOD'),(17,0,'2026-09-28 19:42:58.355568','2026-09-28 19:42:58.355568',3,'Big Spoon',NULL,NULL,NULL,NULL,3.000,'pcs',NULL,3,'GOOD'),(18,0,'2026-09-28 19:42:58.358188','2026-09-28 19:42:58.358188',3,'Small Bowl',NULL,NULL,NULL,NULL,7.000,'pcs',NULL,4,'GOOD'),(19,0,'2026-09-28 19:42:58.358188','2026-09-28 19:42:58.358188',3,'Big Bowl',NULL,NULL,NULL,NULL,3.000,'pcs',NULL,5,'GOOD'),(20,0,'2026-09-30 14:57:03.154686','2026-09-30 14:57:03.154686',4,'Lehnga',NULL,NULL,NULL,NULL,1.000,'pcs',NULL,0,'GOOD'),(21,0,'2026-09-30 14:57:03.167093','2026-09-30 14:57:03.167093',4,'Hair Clip',NULL,NULL,NULL,NULL,2.000,'pcs',NULL,1,'GOOD'),(22,0,'2026-09-30 14:57:03.178106','2026-09-30 14:57:03.178106',4,'Earring',NULL,NULL,NULL,NULL,2.000,'pair',NULL,2,'GOOD'),(23,0,'2026-09-30 14:57:03.186737','2026-09-30 14:57:03.186737',4,'Nose Ring',NULL,NULL,NULL,NULL,2.000,'pcs',NULL,3,'GOOD'),(24,0,'2026-09-30 15:27:56.131261','2026-09-30 15:27:56.131261',5,'Table',NULL,NULL,NULL,NULL,15.000,'pcs',NULL,0,'GOOD'),(25,0,'2026-09-30 15:27:56.138485','2026-09-30 15:27:56.138485',5,'Chair',NULL,NULL,NULL,NULL,60.000,'pcs',NULL,1,'GOOD'),(26,0,'2026-09-30 15:27:56.143536','2026-09-30 15:27:56.143536',5,'Bedsheet',NULL,NULL,NULL,NULL,10.000,'pcs',NULL,2,'GOOD'),(27,0,'2026-09-30 15:27:56.143536','2026-09-30 15:27:56.143536',5,'Mattress',NULL,NULL,NULL,NULL,10.000,'pcs',NULL,3,'GOOD'),(28,0,'2026-10-01 14:29:29.173309','2026-10-01 14:29:29.173309',6,'Table',NULL,NULL,NULL,NULL,1.000,'pcs',NULL,0,'GOOD'),(29,0,'2026-10-01 14:29:29.180602','2026-10-01 14:29:29.180602',6,'Curtain',NULL,NULL,NULL,NULL,3.000,'pcs',NULL,1,'GOOD'),(30,0,'2026-10-01 14:29:29.183678','2026-10-01 14:29:29.183678',6,'Joker Dress',NULL,NULL,NULL,NULL,2.000,'pcs',NULL,2,'GOOD'),(31,0,'2026-10-01 14:29:29.186097','2026-10-01 14:29:29.186097',6,'Balloon Filler',NULL,NULL,NULL,NULL,1.000,'pcs',NULL,3,'GOOD'),(40,0,'2026-10-01 20:59:16.414966','2026-10-01 20:59:16.414966',14,'10th History Book',NULL,NULL,NULL,NULL,6.000,'pcs',NULL,0,'GOOD'),(41,0,'2026-10-01 20:59:16.422256','2026-10-01 20:59:16.422256',14,'Pen',NULL,NULL,NULL,NULL,6.000,'pcs',NULL,1,'GOOD'),(42,0,'2026-10-01 20:59:16.423121','2026-10-01 20:59:16.423121',14,'Exam Pad',NULL,NULL,NULL,NULL,6.000,'pcs',NULL,2,'GOOD'),(43,0,'2026-10-01 20:59:16.423121','2026-10-01 20:59:16.423121',14,'10th Science Book',NULL,NULL,NULL,NULL,5.000,'pcs',NULL,3,'GOOD');
/*!40000 ALTER TABLE `handoff_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recipient_link`
--

DROP TABLE IF EXISTS `recipient_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recipient_link` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `version` bigint NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `handoff_id` bigint NOT NULL,
  `token_hash` varchar(64) NOT NULL,
  `expires_at` datetime(6) NOT NULL,
  `opened_at` datetime(6) DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_recipient_token` (`token_hash`),
  KEY `ix_link_handoff` (`handoff_id`),
  CONSTRAINT `fk_link_handoff` FOREIGN KEY (`handoff_id`) REFERENCES `handoff` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recipient_link`
--

LOCK TABLES `recipient_link` WRITE;
/*!40000 ALTER TABLE `recipient_link` DISABLE KEYS */;
INSERT INTO `recipient_link` VALUES (1,1,'2026-09-28 18:24:11.094924','2026-09-28 18:25:21.564269',1,'c8861cff03ffbe7b34f21f95ad04554e342afe4893a7dbd8c7fa1ec9d24307be','2026-10-28 18:24:11.094924','2026-09-28 18:25:21.541613',0),(2,1,'2026-09-28 19:14:42.094870','2026-09-28 19:14:54.173519',2,'9d2f4d742a3cd718df2e770f5707da4dcdba55459b6aafaeee4312072302301c','2026-10-28 19:14:42.094870','2026-09-28 19:14:54.144816',0),(3,1,'2026-09-28 19:43:05.501749','2026-09-28 19:43:19.299744',3,'6d39d4cbe827a600ff066e4c1395bd76ba9aa1c1fcc0372012dd14e1e9bce481','2026-10-28 19:43:05.501749','2026-09-28 19:43:19.273975',1),(4,1,'2026-09-30 14:57:17.485805','2026-09-30 14:57:42.622218',4,'64858441fa874de69388883f1fb55ade5ce76b6a894fb1561591f52db4262842','2026-10-30 14:57:17.484772','2026-09-30 14:57:42.595678',0),(5,1,'2026-09-30 15:27:59.378176','2026-09-30 15:28:11.232682',5,'a54764fbd49284e04bb888666cc500da2a84e394a9a1f8a0cf8ce8a35d81531d','2026-10-30 15:27:59.374247','2026-09-30 15:28:11.196166',1),(6,1,'2026-10-01 14:16:23.450638','2026-10-01 14:16:32.522665',5,'b6afd506e343798379094c54b6a8eebe91824778dccab314d04839d172010a28','2026-10-31 14:16:23.428577','2026-10-01 14:16:32.482503',0),(7,1,'2026-10-01 14:29:30.904463','2026-10-01 14:29:40.118374',6,'912b6035b2454b42cb6dd4634c28fd75f125eed46f9eefc3bd22aaeace3722ff','2026-10-31 14:29:30.904463','2026-10-01 14:29:40.091160',1),(15,1,'2026-10-01 15:57:48.477055','2026-10-01 15:57:58.719324',3,'8e91a5b442f28cc241fb8b380b192a770633d3cd5ef81f900209e82c7351aaf3','2026-10-31 15:57:48.463981','2026-10-01 15:57:58.667769',0),(16,1,'2026-10-01 15:59:37.337737','2026-10-01 15:59:45.485252',6,'0fffadddf18d6a7c5b3447ecef42225acc13efb9edfdc6b4d90f2d2558db2e44','2026-10-31 15:59:37.336896','2026-10-01 15:59:45.382105',0);
/*!40000 ALTER TABLE `recipient_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `return_event`
--

DROP TABLE IF EXISTS `return_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `return_event` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `version` bigint NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `handoff_id` bigint NOT NULL,
  `occurred_at` datetime(6) NOT NULL,
  `entered_by_type` varchar(20) NOT NULL,
  `entered_by_ref` varchar(200) DEFAULT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `confirmed` tinyint(1) NOT NULL,
  `confirmed_at` datetime(6) DEFAULT NULL,
  `confirmed_by_ref` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_return_event_handoff` (`handoff_id`),
  CONSTRAINT `fk_return_handoff` FOREIGN KEY (`handoff_id`) REFERENCES `handoff` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `return_event`
--

LOCK TABLES `return_event` WRITE;
/*!40000 ALTER TABLE `return_event` DISABLE KEYS */;
INSERT INTO `return_event` VALUES (1,0,'2026-09-28 19:19:49.725514','2026-09-28 19:19:49.725514',2,'2026-09-28 19:19:49.723509','USER','handoffly@gmail.com',NULL,1,'2026-09-28 19:19:49.724553','handoffly@gmail.com'),(2,0,'2026-09-28 19:20:28.216203','2026-09-28 19:20:28.216203',2,'2026-09-28 19:20:28.216203','USER','handoffly@gmail.com',NULL,1,'2026-09-28 19:20:28.216203','handoffly@gmail.com'),(3,0,'2026-09-28 19:49:45.271372','2026-09-28 19:49:45.271372',3,'2026-09-28 19:49:45.269374','USER','handoffly@gmail.com',NULL,1,'2026-09-28 19:49:45.270372','handoffly@gmail.com'),(4,0,'2026-09-30 14:58:51.461798','2026-09-30 14:58:51.461798',4,'2026-09-30 14:58:51.460734','USER','handoffly@gmail.com',NULL,1,'2026-09-30 14:58:51.461263','handoffly@gmail.com'),(5,0,'2026-09-30 15:30:44.023024','2026-09-30 15:30:44.023024',5,'2026-09-30 15:30:44.023024','USER','handoffly@gmail.com',NULL,1,'2026-09-30 15:30:44.023024','handoffly@gmail.com'),(6,0,'2026-09-30 15:41:58.584037','2026-09-30 15:41:58.584037',5,'2026-09-30 15:41:58.571983','USER','handoffly@gmail.com',NULL,1,'2026-09-30 15:41:58.571983','handoffly@gmail.com'),(14,0,'2026-10-01 15:29:48.173693','2026-10-01 15:29:48.173693',5,'2026-10-01 15:29:48.173693','USER','handoffly@gmail.com',NULL,1,'2026-10-01 15:29:48.173693','handoffly@gmail.com'),(15,0,'2026-10-01 15:33:55.671032','2026-10-01 15:33:55.671032',5,'2026-10-01 15:33:55.671032','USER','handoffly@gmail.com',NULL,1,'2026-10-01 15:33:55.671032','handoffly@gmail.com'),(16,0,'2026-10-01 15:47:01.449824','2026-10-01 15:47:01.449824',3,'2026-10-01 15:47:01.442550','USER','handoffly@gmail.com',NULL,1,'2026-10-01 15:47:01.442550','handoffly@gmail.com'),(18,0,'2026-10-01 15:59:27.959354','2026-10-01 15:59:27.959354',6,'2026-10-01 15:59:27.959354','USER','handoffly@gmail.com',NULL,1,'2026-10-01 15:59:27.959354','handoffly@gmail.com'),(20,0,'2026-10-01 18:13:43.441103','2026-10-01 18:13:43.441103',6,'2026-10-01 18:13:43.431976','USER','handoffly@gmail.com',NULL,1,'2026-10-01 18:13:43.431976','handoffly@gmail.com');
/*!40000 ALTER TABLE `return_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `return_line`
--

DROP TABLE IF EXISTS `return_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `return_line` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `version` bigint NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `return_event_id` bigint NOT NULL,
  `handoff_item_id` bigint NOT NULL,
  `quantity` decimal(19,3) NOT NULL,
  `item_condition` varchar(20) NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_return_line_event` (`return_event_id`),
  KEY `ix_return_line_item` (`handoff_item_id`),
  CONSTRAINT `fk_line_event` FOREIGN KEY (`return_event_id`) REFERENCES `return_event` (`id`),
  CONSTRAINT `fk_line_item` FOREIGN KEY (`handoff_item_id`) REFERENCES `handoff_item` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `return_line`
--

LOCK TABLES `return_line` WRITE;
/*!40000 ALTER TABLE `return_line` DISABLE KEYS */;
INSERT INTO `return_line` VALUES (1,0,'2026-09-28 19:19:49.729511','2026-09-28 19:19:49.729511',1,10,1.000,'GOOD','ok'),(2,0,'2026-09-28 19:19:49.733846','2026-09-28 19:19:49.733846',1,11,1.000,'GOOD','ok'),(3,0,'2026-09-28 19:19:49.735137','2026-09-28 19:19:49.735137',1,12,1.000,'GOOD','ok'),(4,0,'2026-09-28 19:20:28.218947','2026-09-28 19:20:28.218947',2,13,1.000,'GOOD','ok'),(5,0,'2026-09-28 19:49:45.275250','2026-09-28 19:49:45.275250',3,14,6.000,'GOOD',NULL),(6,0,'2026-09-28 19:49:45.278271','2026-09-28 19:49:45.278271',3,15,7.000,'GOOD',NULL),(7,0,'2026-09-28 19:49:45.280401','2026-09-28 19:49:45.280401',3,16,7.000,'GOOD',NULL),(8,0,'2026-09-28 19:49:45.281399','2026-09-28 19:49:45.281399',3,17,3.000,'GOOD',NULL),(9,0,'2026-09-28 19:49:45.283952','2026-09-28 19:49:45.283952',3,18,7.000,'GOOD',NULL),(10,0,'2026-09-28 19:49:45.284950','2026-09-28 19:49:45.284950',3,19,3.000,'GOOD',NULL),(11,0,'2026-09-30 14:58:51.465600','2026-09-30 14:58:51.465600',4,20,1.000,'GOOD',NULL),(12,0,'2026-09-30 14:58:51.473496','2026-09-30 14:58:51.473496',4,21,2.000,'GOOD',NULL),(13,0,'2026-09-30 14:58:51.475633','2026-09-30 14:58:51.475633',4,22,2.000,'GOOD',NULL),(14,0,'2026-09-30 14:58:51.476639','2026-09-30 14:58:51.476639',4,23,2.000,'GOOD',NULL),(15,0,'2026-09-30 15:30:44.032034','2026-09-30 15:30:44.032034',5,24,13.000,'GOOD',NULL),(16,0,'2026-09-30 15:30:44.037483','2026-09-30 15:30:44.037483',5,25,60.000,'GOOD',NULL),(17,0,'2026-09-30 15:30:44.039576','2026-09-30 15:30:44.039576',5,26,10.000,'GOOD',NULL),(18,0,'2026-09-30 15:30:44.040990','2026-09-30 15:30:44.040990',5,27,10.000,'GOOD',NULL),(19,0,'2026-09-30 15:41:58.630545','2026-09-30 15:41:58.630545',6,24,2.000,'MISSING',NULL),(27,0,'2026-10-01 15:29:48.205996','2026-10-01 15:29:48.205996',14,24,1.000,'GOOD',NULL),(28,0,'2026-10-01 15:33:55.678270','2026-10-01 15:33:55.678270',15,24,1.000,'GOOD',NULL),(29,0,'2026-10-01 15:47:01.527300','2026-10-01 15:47:01.527300',16,14,1.000,'MISSING',NULL),(31,0,'2026-10-01 15:59:28.008452','2026-10-01 15:59:28.008452',18,28,1.000,'GOOD',NULL),(32,0,'2026-10-01 15:59:28.015309','2026-10-01 15:59:28.015309',18,29,2.000,'GOOD',NULL),(33,0,'2026-10-01 15:59:28.018884','2026-10-01 15:59:28.018884',18,29,1.000,'MISSING',NULL),(34,0,'2026-10-01 15:59:28.018884','2026-10-01 15:59:28.018884',18,30,2.000,'GOOD',NULL),(35,0,'2026-10-01 15:59:28.023455','2026-10-01 15:59:28.023455',18,31,1.000,'GOOD',NULL),(37,0,'2026-10-01 18:13:43.488437','2026-10-01 18:13:43.488437',20,29,1.000,'GOOD',NULL);
/*!40000 ALTER TABLE `return_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequence_counter`
--

DROP TABLE IF EXISTS `sequence_counter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequence_counter` (
  `name` varchar(40) NOT NULL,
  `next_value` bigint NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequence_counter`
--

LOCK TABLES `sequence_counter` WRITE;
/*!40000 ALTER TABLE `sequence_counter` DISABLE KEYS */;
INSERT INTO `sequence_counter` VALUES ('ACCOUNT',10),('STAFF',1),('TICKET',1);
/*!40000 ALTER TABLE `sequence_counter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_audit_event`
--

DROP TABLE IF EXISTS `support_audit_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_audit_event` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `version` bigint NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `staff_id` bigint NOT NULL,
  `customer_id` bigint NOT NULL,
  `event_type` varchar(30) NOT NULL,
  `previous_value` varchar(60) NOT NULL,
  `new_value` varchar(60) NOT NULL,
  `reason` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_support_audit_staff` (`staff_id`),
  KEY `ix_support_audit_customer` (`customer_id`,`id`),
  CONSTRAINT `fk_support_audit_customer` FOREIGN KEY (`customer_id`) REFERENCES `app_user` (`id`),
  CONSTRAINT `fk_support_audit_staff` FOREIGN KEY (`staff_id`) REFERENCES `support_staff` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_audit_event`
--

LOCK TABLES `support_audit_event` WRITE;
/*!40000 ALTER TABLE `support_audit_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_audit_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_staff`
--

DROP TABLE IF EXISTS `support_staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_staff` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `version` bigint NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `staff_code` varchar(20) NOT NULL,
  `name` varchar(150) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(100) NOT NULL,
  `role` varchar(20) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_support_staff_code` (`staff_code`),
  UNIQUE KEY `uq_support_staff_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_staff`
--

LOCK TABLES `support_staff` WRITE;
/*!40000 ALTER TABLE `support_staff` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_ticket`
--

DROP TABLE IF EXISTS `support_ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_ticket` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `version` bigint NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `ticket_code` varchar(20) NOT NULL,
  `account_user_id` bigint NOT NULL,
  `category` varchar(30) NOT NULL,
  `contact_method` varchar(20) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `description` varchar(5000) NOT NULL,
  `handoff_reference` varchar(20) DEFAULT NULL,
  `contact_phone` varchar(40) DEFAULT NULL,
  `status` varchar(30) NOT NULL,
  `message_count` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_support_ticket_code` (`ticket_code`),
  KEY `ix_ticket_account` (`account_user_id`),
  KEY `ix_ticket_status` (`status`,`updated_at`),
  CONSTRAINT `fk_ticket_account` FOREIGN KEY (`account_user_id`) REFERENCES `app_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_ticket`
--

LOCK TABLES `support_ticket` WRITE;
/*!40000 ALTER TABLE `support_ticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_ticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_ticket_attachment`
--

DROP TABLE IF EXISTS `support_ticket_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_ticket_attachment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `version` bigint NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `ticket_id` bigint NOT NULL,
  `storage_key` varchar(100) NOT NULL,
  `original_filename` varchar(255) NOT NULL,
  `content_type` varchar(100) NOT NULL,
  `size_bytes` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_ticket_attachment_ticket` (`ticket_id`),
  CONSTRAINT `fk_ticket_attachment_ticket` FOREIGN KEY (`ticket_id`) REFERENCES `support_ticket` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_ticket_attachment`
--

LOCK TABLES `support_ticket_attachment` WRITE;
/*!40000 ALTER TABLE `support_ticket_attachment` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_ticket_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_ticket_message`
--

DROP TABLE IF EXISTS `support_ticket_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_ticket_message` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `version` bigint NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `ticket_id` bigint NOT NULL,
  `author_user_id` bigint DEFAULT NULL,
  `author_role` varchar(20) NOT NULL,
  `body` varchar(5000) NOT NULL,
  `author_staff_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_message_author` (`author_user_id`),
  KEY `ix_ticket_message_ticket` (`ticket_id`),
  KEY `fk_message_author_staff` (`author_staff_id`),
  CONSTRAINT `fk_message_author` FOREIGN KEY (`author_user_id`) REFERENCES `app_user` (`id`),
  CONSTRAINT `fk_message_author_staff` FOREIGN KEY (`author_staff_id`) REFERENCES `support_staff` (`id`),
  CONSTRAINT `fk_message_ticket` FOREIGN KEY (`ticket_id`) REFERENCES `support_ticket` (`id`),
  CONSTRAINT `ck_message_one_author` CHECK ((((`author_user_id` is not null) and (`author_staff_id` is null)) or ((`author_user_id` is null) and (`author_staff_id` is not null))))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_ticket_message`
--

LOCK TABLES `support_ticket_message` WRITE;
/*!40000 ALTER TABLE `support_ticket_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_ticket_message` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-02  4:52:14
